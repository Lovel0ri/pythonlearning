# @Time: 2022/9/23 0:19
# @Author: 李树斌
# @File : alien.py
# @Software :PyCharm
import pygame
from pygame.sprite import Sprite

class Alien(Sprite):
    """表示单个外星人的类"""

    def __init__(self,ai_game):
        """初始化外星人并设置起起始位置"""
        super().__init__()
        self.screen = ai_game.screen

        #加载外星人图像并设置rect属性
        self.image = pygame.image.load('images/alien.png')
        self.rect = self.image.get_rect()

        #每个外星人最初都在屏幕左上角附近
        self.rect.x = self.rect.width
        self.rect.y = self.rect.height

        #存储外星人的精确水平
        self.rect.x = float(self.rect.x)
