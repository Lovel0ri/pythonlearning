# @Time : 2022/8/29  17:27
# @Author: 李树斌
# @File : test0.py
# @Software : PyCharm

#这是一个单行注释
print("hello,world")#这是我的第一个程序

'''这是多行注释'''