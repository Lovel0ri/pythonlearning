# @Time : 2022/8/31  16:56
# @Author: 李树斌
# @File : setup.py
# @Software : PyCharm

from distutils.core import setup
setup(
    name    = 'nesterbing',
    version = '1.3.7',
    py_modules = ['nesterbing'],
    author = '冰冰', #作者
    author_email = '2697601945@qq.com',
    url = 'http://www.headfristlabs.com',
    description = 'A simple printer of nester lists',#简介内容
)