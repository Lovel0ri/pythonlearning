# @Time : 2022/8/30  22:19
# @Author: 李树斌
# @File : for处理列表.py
# @Software : PyCharm

# for(指示循环的开始) 目标标识符 in(将目标标识符与列表分隔开) 列表 :(指示列表处理开始)
#   列表处理代码

#创建列表
movies = [ "The Holy grail", "The life of Brian"]
for each_movie in movies:
    print(each_movie)
