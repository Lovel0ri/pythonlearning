# @Time : 2022/8/30  19:54
# @Author: 李树斌
# @File : test.py
# @Software : PyCharm
import time
print(time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time())))
#你好骚杰！
# hello，my boy
