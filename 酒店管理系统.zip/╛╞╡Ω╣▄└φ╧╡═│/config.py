# @Time: 2022/11/9 20:58



data:{
    "manager_name": "admin",
    "manager_password": "123456"
}

waiter_all:{
    "1":{
        "waiter_name": "waiter1",
        "waiter_password": "123456"

    },
    "2":{
        "waiter_name": "waiter2",
        "waiter_password": "123456"

    }
}

room_manager_all:{
}


guest_all:{

}

room_all:{
    "single_commonroom":{
},
    "double_commonroom":{
},
    "single_deluxeroom":{
},
    "double_deluxeroom":{
}
}

order_all:{

}
services_all:{
}

feedback_all:{
}
